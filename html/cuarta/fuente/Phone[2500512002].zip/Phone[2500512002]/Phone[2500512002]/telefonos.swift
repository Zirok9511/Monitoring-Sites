//
//  telefonos.swift
//  Phone[2500512002]
//
//  Created by Development on 10/11/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

import Foundation

class telefonos {

    var nombre: String = ""
    var fabricacion: String = ""
    var tamanio: String = ""
    
}