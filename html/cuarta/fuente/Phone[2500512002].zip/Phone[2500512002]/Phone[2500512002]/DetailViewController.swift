//
//  DetailViewController.swift
//  Phone[2500512002]
//
//  Created by Development on 10/11/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var detailDescriptionLabel: UILabel!

    @IBOutlet weak var lblNombre: UILabel!
    
    @IBOutlet weak var lblFabricacion: UILabel!
    
    @IBOutlet weak var lbltamaño: UILabel!
    

    var detailItem: AnyObject? {
        didSet {
            // Update the view.
           
        }
    }

    func configureView() {
        // Update the user interface for the detail item.
        
        if let detailItem: AnyObject = self.detailItem {
        
            let tel = detailItem as! telefonos
            lblNombre.text = tel.nombre
            lblFabricacion.text = tel.fabricacion
            lbltamaño.text = tel.tamanio
            
        }
        
       
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.configureView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

