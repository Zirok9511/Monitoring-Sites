//
//  detalle.swift
//  Phone[2500512002]
//
//  Created by Development on 10/11/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

import Foundation

class detalle{
    
    var detallecel: [telefonos] = []
    
    init(){
    
    var tel = telefonos()
        
        tel.nombre = "IPhone 5s"
        tel.fabricacion = "12 de dic 2017"
        tel.tamanio = "15,5 pulgadas"
        detallecel.append(tel)
        
        
        
        tel = telefonos()
        tel.nombre = "IPhone 6"
        tel.fabricacion = "15 octubre 2018"
        tel.tamanio = "10,0 pulgadas"
        detallecel.append(tel)
        
        
        
        tel = telefonos()
        tel.nombre = "IPhone 6s"
        tel.fabricacion = "12 Noviembre 2018"
        tel.tamanio = "13,5 pulgadas"
        detallecel.append(tel)
        
        
    }
    
    
    
    
    
 


}