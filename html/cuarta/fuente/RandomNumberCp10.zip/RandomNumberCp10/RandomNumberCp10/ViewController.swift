//
//  ViewController.swift
//  RandomNumberCp10
//
//  Created by Development on 3/11/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var randomNumberLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func seedAction(sender: UIButton) {
        randomNumberLabel.text = "Generator seended"
    }
    
    
    @IBAction func generateAction(sender: UIButton) {
        
        let generated = (random()%100)+1
        
        randomNumberLabel.text = "\(generated)"
    }
    
}

