//
//  Categoria+CoreDataProperties.swift
//  Producto2539152015
//
//  Created by development on 11/16/19.
//  Copyright © 2019 development. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData


extension Categoria {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Categoria> {
        return NSFetchRequest<Categoria>(entityName: "Categoria");
    }

    @NSManaged public var nombreCategoria: String?
    @NSManaged public var codigoCategoria: Int16
    @NSManaged public var categoriaproducto: NSSet?

}

// MARK: Generated accessors for categoriaproducto
extension Categoria {

    @objc(addCategoriaproductoObject:)
    @NSManaged public func addToCategoriaproducto(_ value: Producto)

    @objc(removeCategoriaproductoObject:)
    @NSManaged public func removeFromCategoriaproducto(_ value: Producto)

    @objc(addCategoriaproducto:)
    @NSManaged public func addToCategoriaproducto(_ values: NSSet)

    @objc(removeCategoriaproducto:)
    @NSManaged public func removeFromCategoriaproducto(_ values: NSSet)

}
