//
//  ViewController.swift
//  Producto2539152015
//
//  Brian Alberto Guadron Ramirez
//  25-3915-2015
//  Created by development on 11/16/19.
//  Copyright © 2019 development. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

