//
//  Medida+CoreDataProperties.swift
//  Producto2539152015
//
//  Created by development on 11/16/19.
//  Copyright © 2019 development. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData


extension Medida {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Medida> {
        return NSFetchRequest<Medida>(entityName: "Medida");
    }

    @NSManaged public var codigoMedida: Int16
    @NSManaged public var nombreMedida: String?
    @NSManaged public var medidaproducto: NSSet?

}

// MARK: Generated accessors for medidaproducto
extension Medida {

    @objc(addMedidaproductoObject:)
    @NSManaged public func addToMedidaproducto(_ value: Producto)

    @objc(removeMedidaproductoObject:)
    @NSManaged public func removeFromMedidaproducto(_ value: Producto)

    @objc(addMedidaproducto:)
    @NSManaged public func addToMedidaproducto(_ values: NSSet)

    @objc(removeMedidaproducto:)
    @NSManaged public func removeFromMedidaproducto(_ values: NSSet)

}
