//
//  Medida+CoreDataClass.swift
//  Producto2539152015
//
//  Created by development on 11/16/19.
//  Copyright © 2019 development. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData

@objc(Medida)
public class Medida: NSManagedObject {

}
