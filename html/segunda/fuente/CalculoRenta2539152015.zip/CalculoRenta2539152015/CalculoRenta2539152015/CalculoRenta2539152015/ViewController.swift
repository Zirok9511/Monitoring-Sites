//
//  ViewController.swift
//  CalculoRenta2539152015
//  Brian Alberto Guadron Ramirez 25-3915-2015
//  Created by development on 10/26/19.
//  Copyright © 2019 2539152015. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var mypicker: UIPickerView!
    @IBOutlet weak var txtSalario: UIPickerView!
    
    @IBAction func btnCalcular(_ sender: Any) {
        
        Salario = Double(txtsalarioo.text!)!
        //objcalculo.Calculo(modalidad)
        
    }
    @IBOutlet weak var txtsalarioo: UITextField!
    @IBOutlet weak var txtsalariorenta: UITextField!
    @IBOutlet weak var txtRenta: UITextField!
    @IBOutlet weak var txtvalor: UITextField!
    
    var Salario: Double = 0.0
    var modalidad: Int = 0
    var valorRenta: Double = 0.0
    
    var objcalculo: clscalculo
    
    required init?(coder aDecoder: NSCoder){
        objcalculo = clscalculo()
        
        super.init(coder: aDecoder)
    }
    
    
    let pickerE = ["Mensual","Quincenal","Semanal"]
    override func viewDidLoad() {
        super.viewDidLoad()
        mypicker.dataSource = self
        mypicker.delegate = self
        
        txtvalor.isHidden = true
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerE.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerE[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        modalidad =  row
    }


}

