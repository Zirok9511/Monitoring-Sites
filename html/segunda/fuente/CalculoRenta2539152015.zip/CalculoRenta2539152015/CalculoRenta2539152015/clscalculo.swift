//
//  clscalculo.swift
//  CalculoRenta2539152015
//
//  Created by development on 10/26/19.
//  Copyright © 2019 2539152015. All rights reserved.
//

import UIKit

class clscalculo: NSObject {
    
    var salario: Double = 0.0
    var valorImpuesto: Double = 0.0
    
    class func pagoMensual(impuesto: Double) -> Double{
        return impuesto
    }
    
    func Calculo(calc: Double){
        if calc == 0 {
            
        }
    }

}
