//
//  ViewController.swift
//  pedidoventa2539152015
//
//Brian Alberto Guadron Ramirez
//25 - 3915 - 2015
//  Created by development on 10/19/19.
//  Copyright © 2019 development. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource{
    @IBOutlet weak var cliente: UITextField!
    @IBOutlet weak var producto: UITextField!
    @IBOutlet weak var unidades: UITextField!
    @IBOutlet weak var precio: UITextField!
    @IBOutlet weak var total: UILabel!
    @IBOutlet weak var btnBorrar: UIButton!
    @IBOutlet weak var btnLeer: UIButton!
    @IBOutlet weak var btnActualizar: UIButton!
    @IBOutlet weak var marca: UIPickerView!
    @IBOutlet weak var btnAgregar: UIButton!
    var clientes : Array<String> = []
    var productos : Array<String> = []
    var unid : Array<Double> = []
    var marcass : Array<String> = []
    var precios : Array<Double> = []
    var totales : Array<Double> = []
    let marc : [String] = ["Pringles" , "Lays" , "Diana" , "Sabritas" , "Ruffles"]
    var to: Double = 0.0
    var uni: Double = 0.0
    var pre: Double = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        self.marca.dataSource = self
        self.marca.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func agregar(_ sender: Any) {
        clientes.append(cliente.text!)
        productos.append(producto.text!)
        precios.append(Double(precio.text!)!)
        unid.append(Double(unidades.text!)!)
        marcass.append(marca.dataSource as! String)
        uni =  Double(unidades.text!)!
        pre = Double(precio.text!)!
        to = uni * pre

        //to = (total.text!)
    }
    @IBAction func actualizar(_ sender: Any) {
    }
    @IBAction func borrar(_ sender: Any) {
    }
    @IBAction func leer(_ sender: Any) {
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return marc.count
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return marc[row]
    }
    func ecuacion(){
        //total = prec * unid
    }

}

