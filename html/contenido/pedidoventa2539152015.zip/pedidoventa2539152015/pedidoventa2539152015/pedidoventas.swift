//
//  pedidoventas.swift
//  pedidoventa2539152015
//
//  Created by development on 10/19/19.
//  Copyright © 2019 development. All rights reserved.
//

import UIKit

class pedidoventas: NSObject {
    
    var nombre: String
    var producto: String
    var unidades: Double
    var precio: Double
    var total: Double
    
    override init(){
        nombre = "default"
        producto = "default"
        unidades = 0
        precio = 0.0
        total = 0.0
    }
    
    
    func Total(unid: Double, pre: Double) -> Double {
        total = precio * unidades
        return total
    }
    
    
    
    
}
