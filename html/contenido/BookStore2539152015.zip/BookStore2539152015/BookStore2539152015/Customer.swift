//
//  Customer.swift
//  BookStore2539152015
//
//  Created by Brian Alberto Guadron Ramirez on 10/12/19.
//  Copyright © 2019 development. All rights reserved.
//

import UIKit

class Customer: NSObject {
    var firstName = ""
    var lastName = ""
    var addressLine1 = ""
    var addressLine2 = ""
    var city = ""
    var state = ""
    var zip = ""
    var phoneNumber = ""
    var emailAddress = ""
    var favoriteGenere = ""
    
    func listPurchaseHistory() -> [String] {
        return ["Purchase 1", "Purchase 2"]
    }

}
