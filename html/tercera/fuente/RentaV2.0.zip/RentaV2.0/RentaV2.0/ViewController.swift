//
//  ViewController.swift
//  RentaV2.0
//
//  Created by Alberto on 17/10/18.
//  Copyright © 2018 Alberto. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var lblSalario: UITextField!
    
    
    @IBOutlet weak var lblPago: UITextField!
    
    
    @IBOutlet weak var lblDesc: UILabel!
    
    
    
    @IBOutlet weak var btnCalcular: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @IBAction func clickCalcular(sender: UIButton) {
        
        let objcalculo : ImpuestoRenta0 = ImpuestoRenta0()
        objcalculo.salario=NSString(string: lblSalario.text!).doubleValue
        var lbdtipo: Int=0
        lbdtipo = Int(lblPago.text!)!
        
        switch lbdtipo
        {
        case 1:
            objcalculo.rentamensual()
            
        case 2:
            objcalculo.rentaquincenal()
            
        case 3:
            objcalculo.rentasemana()
            
        default:
            let mensaje:String = "x"
            lblDesc.text = mensaje
            
        }
        lblDesc.text = "$" + objcalculo.impuesto.description
        
        
        
    }


}

