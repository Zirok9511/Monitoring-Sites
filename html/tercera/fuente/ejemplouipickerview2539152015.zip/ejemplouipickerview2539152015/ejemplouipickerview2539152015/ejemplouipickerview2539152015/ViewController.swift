//
//  ViewController.swift
//  ejemplouipickerview2539152015
//
//  Created by development on 10/12/19.
//  Copyright © 2019 Brian Alberto Guadron Ramirez. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {


    @IBOutlet weak var mypicker: UIPickerView!
    @IBOutlet weak var mylabel: UILabel!
    let pickerData = ["Mozarella","Gorgonzola","Provolone","Brie","Maytag Blue","Sharp Cheddar","Monterrey Jack","Stilton","Gouda","Goat Cheese","Asiago"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mypicker.dataSource = self
        mypicker.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @available(iOS 2.0, *)
    func numberOfComponents(in pickerView: UIPickerView) -> Int{
    return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
    
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int ) {
        mylabel.text = pickerData[row]
    }

}

