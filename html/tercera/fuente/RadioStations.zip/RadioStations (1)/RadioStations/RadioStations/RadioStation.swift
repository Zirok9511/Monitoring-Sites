//
//  RadioStation.swift
//  RadioStations
//
//  Created by development on 10/18/19.
//  Copyright © 2019 Zirok9511. All rights reserved.
//

import UIKit

class RadioStation: NSObject {
    var name: String
    var frequency: Double
    
    override init(){
        name = "default"
        frequency = 100
    }
    
    class func minAMFrequency() -> Double {
        return 520.0
    }
    
    class func maxAMFrequency() -> Double {
        return 1610.0
    }
    
    class func minFMFrequency() -> Double {
        return 88.3
    }
    
    class func maxFMFrequency() -> Double {
        return 107.9
    }
    
    func band() -> Int {
        if frequency >= RadioStation.minFMFrequency() && frequency <= RadioStation.maxFMFrequency(){
            return 1
        }else{
            return 0
        }
    }
    
    func band2() -> Int {
        if frequency >= RadioStation.minAMFrequency() && frequency <= RadioStation.maxAMFrequency(){
            return 1
        }else{
            return 0
        }
    }

}
