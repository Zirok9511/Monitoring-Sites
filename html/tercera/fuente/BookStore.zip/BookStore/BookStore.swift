//
//  BookStore.swift
//  BookStore
//
//  Created by Alberto on 13/11/18.
//  Copyright © 2018 Alberto. All rights reserved.
//

import Foundation

class Book {}