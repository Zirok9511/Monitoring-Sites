//
//  CalcComisiones.swift
//  practicaEV13102018
//
//  Created by Development on 13/10/18.
//  Copyright © 2018 Carlitox. All rights reserved.
// ALBERTO JOSE ROSA ESTRADA 25-0051-2002

import Foundation

class CalcComisiones
{
    var unidades:Double=0.00
    var comision:Double=0.00
    var premio:Int=0
    var cantidad:Double=0.00
    
    func calcular(){
        
        
        if (unidades>=0 && unidades<=100)
        {
            comision = 0.01
            premio=0
            cantidad = unidades * comision
            
        }
        
            if (unidades>=150 && unidades<=200)
            {
                comision = 0.03
                //premio = 10
                cantidad = (unidades * comision) + 10
                
            }
            
            if (unidades>=201 && unidades<=300)
            {
                comision = 0.05
                premio = 0
                 cantidad = unidades * comision
            }
            
            if (unidades>=301 && unidades<=400)
            {
                comision = 0.06
                premio = 0
                cantidad = unidades * comision
                
            }
            if (unidades>=475 && unidades<=500)
            {
                comision = 0.08
                //premio = 20
                cantidad = (unidades * comision)+20
            }
            if (unidades>=500)
            {
                comision = 0.09
                premio = 0
                cantidad = unidades * comision
            }
            
        }
    
    }

