//
//  ViewController.swift
//  practicaEV13102018
//
//  Created by Development on 13/10/18.
//  Copyright © 2018 Carlitox. All rights reserved.
//  ALBERTO JOSE ROSA ESTRADA
//  2500512002

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtunidades: UITextField!
    
    
    @IBOutlet weak var lblComin: UILabel!
    
    
    @IBOutlet weak var btncalcular: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func clickcalcular(sender: AnyObject) {
        
        let obj:CalcComisiones = CalcComisiones()
        
        obj.unidades = NSString(string: txtunidades.text!).doubleValue
        
        lblComin.text = obj.cantidad.description
        
        
    }
}

