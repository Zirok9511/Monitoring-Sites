

var d = [0,1,2,3,4];

for p in d
{
   print("d=\(p)")
}




var a = ["Uva","Pera","Piña","Manzana"]


a.insert("Mango", atIndex: 4)

a.count

for i in a
{
    print("Las frutas son =  \(i)")
}

a.append("Pera")
a.append("Cereza")




