//: Playground - noun: a place where people can play

//declaracion de variables y constantes

import UIKit

var str = "Hello, playground"

var myString  = "42"
let someInteger = Int(myString)

print(someInteger)