//
//  ViewController.swift
//  Chapter62539152015
//
//  Created by development on 10/12/19.
//  Copyright © 2019 com.innovativeware. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var  nameLabe: UILabel!
    @IBAction func showName(sender:AnyObject){
    
        nameLabe.text="My name is Brian!";
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

