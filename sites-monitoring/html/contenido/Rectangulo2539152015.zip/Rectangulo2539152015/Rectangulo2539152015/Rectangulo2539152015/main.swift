//
//  main.swift
//  Rectangulo2539152015
//
//  Created by development on 9/21/19.
//  Copyright © 2019 development. All rights reserved.
//  Brian Alberto Guadron Ramirez
//  2539152015

import Foundation

var base: Double = 0.0;
var altura: Double = 0.0;
var area: Double = 0.0;
var bases = [Double]()
var alturas = [Double]()
var areas = [Double]()
var operaciones = [Int]()
var oper: Int = 0
var seg: String
func pedir() -> String {
    var input = NSString(data: FileHandle.standardInput.availableData, encoding: String.Encoding.utf8.rawValue)! as String;
    input = input.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil);
    return input;
}



func formula(Base: Double, Altura: Double) -> Double{
    area = base * altura;
    return area;
}

func seguir(){
    print("Calculo del area - [Rectangulo]");
    print("Base: ");
    base = Double(pedir())!
    print("Altura:");
    altura = Double(pedir())!
    print("Area:")
    area = formula(Base: base, Altura: altura)
    print(area)
    
    alturas.append(altura)
    bases.append(base)
    areas.append(area)
    operaciones.append(oper)
    //print(bases)

}

for _ in 1...5 {
        seguir()
    oper = oper+1;
    operaciones.append(oper)
}

print("Realizar otro calculo Y/N");
seg = pedir();
if seg == "Y"{
    seguir()
}


print("-------------------------------------")
print("|# Operacion | Base | Altura | Area |")
print("-------------------------------------")
for contador in 0...oper-1{
    var Altura = alturas[contador]
    var Base = bases[contador]
    var Area = areas[contador]
    var Operacion = operaciones[contador]
    var impresion = "| \(operaciones[contador+1]) | \(bases[contador+1]) | \(alturas[contador+1]) | \(areas[contador+1]) |" ;
    print(impresion)
    
}



