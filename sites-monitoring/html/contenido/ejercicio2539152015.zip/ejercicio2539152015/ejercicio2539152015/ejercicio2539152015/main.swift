				//
//  main.swift
//  ejercicio2539152015
//
//  Created by development on 9/19/19.
//  Copyright © 2019 development. All rights reserved.
//

import Foundation

                
                func pedir()->String
                {
                    var Str1: String = NSString(data: FileHandle.standardInput.availableData, encoding:String.Encoding.utf8.rawValue)! as String;
                    Str1 = Str1.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal , range: nil);
                    return Str1;
                }
                
                func rentas(Salario: Double, Periodo: Int )->Double
                {
                    var renta:Double = 0.0;
                    
                    if Periodo==1
                    {
                        if Salario >= 0.01 && Salario<=118.00
                        {
                            renta = 0.0
                        }else if Salario >= 118.01 && Salario <= 223.81
                        {
                            renta = ((Salario-118.00)*0.10)+4.42
                        }
                        else if Salario >= 223.82 && Salario <= 509.52
                        {
                            renta = ((Salario-223.81)*0.20)+15.00
                        }
                        else if Salario >= 509.53
                        {
                            renta = ((Salario-509.52)*0.30)+72.14
                        }else{
                            print("Ingrese una Salario Valido");
                        }
                        
                    }else if Periodo==2
                    {
                        if Salario >= 0.01 && Salario<=236.00{
                            renta = 0.0
                        }
                        if Salario >= 236.01 && Salario <= 447.62{
                            
                            renta = ((Salario-236.00)*0.10)+8.83
                        }
                        else if Salario >= 447.63 && Salario <= 1019.05
                        {
                            renta = ((Salario-447.62)*0.20)+30.00
                        }
                        else if Salario >= 1019.06
                        {
                            renta = ((Salario-1019.05)*0.30)+144.28
                        }else{
                            print("Ingrese una Salario Valido");
                        }
                    }else if Periodo == 3
                    {
                        if Salario >= 0.01 && Salario<=472.00{
                            renta = 0.0
                        }
                        if Salario >= 472.01 && Salario <= 895.24{
                            
                            renta = ((Salario-472.00)*0.10)+17.67
                        }
                        else if Salario >= 895.25 && Salario <= 2038.10
                        {
                            renta = ((Salario-895.24)*0.20)+60.00
                        }
                        else if Salario >= 2038.11
                        {
                            renta = ((Salario-2038.10)*0.30)+288.57
                        }else{
                            print("Ingrese una Salario Valido");
                        }
                    }else
                    {
                        print("Ingrese un Periodo de tiempo Valido")
                    }
                    return renta;
                }
                
                func Isss(Salario: Double)->Double{
                    
                    let Isss:Double = Salario * 0.03;
                    return Isss;
                }
                
                func Afp(Salario: Double)->Double{
                    
                    let Afps:Double = Salario * 0.03;
                    return Afps;
                }
                
                func tiempoafp(Afp: Double, Perio: Int)->Double{
                    var  Afps=Afp;
                    
                    if Perio == 1 {
                        
                        Afps = Afp/4;
                    }
                    else if Perio == 2{
                        
                        Afps = Afp/2;
                    }
                    return Afps;
                }
                
                func tiempoIsss(Isss: Double, Perio: Int)->Double{
                    var  IssS=Isss;
                    
                    if Perio == 1 {
                        
                        IssS = Isss/4;
                    }
                    else if Perio == 2{
                        
                        IssS = Isss/2;
                    }
                    return IssS;
                }
                
                
                var Nombres = [String]();
                var Codigos = [String]();
                var Salarios = [Double]();
                var Liquidos = [Double]();
                var ISSS = [Double]();
                var AFP = [Double]();
                var RENTA = [Double]();
                var isss : Double = 0.0;
                var afp : Double = 0.0;
                var renta : Double = 0.0;
                var Codigo : String = "";
                var Salario : Double = 0.0;
                var Nombre : String = "";
                print("Ingrese la Cantidad de Empleados: ");
                var nEmpleados = pedir();
                let NEmpleados : Int = Int(nEmpleados)!;
                
                var p = false;
                var Periodo : Int = 0;
                repeat{
                    print("ingrese el periodo de pago: 1.Semanal 2.Quincenal 3.Mensual");
                    Periodo = Int(pedir())!;
                    if Periodo <= 3 && Periodo > 0
                    {
                        p = true;
                    }
                }while p == false;
                
                for Contador in 0...NEmpleados-1{
                    
                    print("Codigo de Empleado");
                    Codigo = pedir();
                    print("Nombre del Empleado");
                    Nombre = pedir();
                    print("Salario del empleado");
                    Salario = Double(pedir())!;
                    Codigos.append(Codigo);
                    Nombres.append(Nombre);
                    Salarios.append(Salario);
                    afp = Afp(Salario: Salario);
                    isss = Isss(Salario: Salario);
                    afp = tiempoafp(Afp: afp, Perio: Periodo);
                    isss = tiempoIsss(Isss: isss, Perio: Periodo);
                    AFP.append(afp);
                    ISSS.append(isss);
                    renta = rentas(Salario: Salario, Periodo: Periodo);
                    RENTA.append(renta);
                    Liquidos.append(Salario-(isss+afp+renta));
                    
                }
                
                print("*-----------------------------------------------------------------------------*");
                print("| Codigo | Nombre | Salario |     Descuentos     | Total  Descuento | Salario |");
                print("|        |        |         *--------------------*                  |         |");
                print("|        |        |         | ISSS | AFP | Renta |                  |         |");
                print("*-----------------------------------------------------------------------------*");
                
                for contador in 0...NEmpleados-1
                {
                    
                    
                    print("| \(Codigos[contador]) | \(Nombres[contador]) | \(Salarios[contador]) | \(ISSS[contador]) | \(AFP[contador]) | \(RENTA[contador]) | \(Liquidos[contador]) | \(Salarios[contador]) |");
                    print("*-----------------------------------------------------------------------------*");
                    
                }

