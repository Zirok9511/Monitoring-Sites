//
//  impuestoRenta.swift
//  CalculandoRenta
//
//  Created by Development on 9/3/19.
//  Copyright © 2019 BRIAN. All rights reserved.
//

import Foundation

class impuestoRenta
{
    var salario:Double = 0.00;
    var impuesto:Double = 0.00;
    
    func rentamensual()
    {
        if(salario >= 0.01 && salario <= 472.00){
            impuesto = 0.00;
        }
        else if(salario <= 895.24){
            impuesto = ((salario - 472.00) * 10) + 17.67;
            
        }
        else if(salario  <= 2038.10){
            impuesto = ((salario - 895.24) * 20) + 60.00;
        }
        else if(salario  >= 2038.10){
            impuesto = ((salario - 2038.10) * 30) + 288.57;
        }
    }
    
    func rentaquincenal()
    {
        switch salario{
        case 0.01...472.00:
            impuesto = 0.00
            
            case 236.01...447.62:
            impuesto = ((salario - 236.00) * 10) + 8.83;
            
        case 447.63...1019.05:
            impuesto = ((salario - 447.63) * 20) + 30.00;
            
        default:
             impuesto = ((salario - 1019.06) * 30) + 144.28;
            
        }
        
    }
    
    func rentasemanal()
    {
        if(salario >= 0.01 && salario <= 118.00){
            impuesto = 0.00;
        }
        else if(salario <= 223.81){
            impuesto = ((salario - 118.00) * 10) + 4.42;
            
        }
        else if(salario  <= 509.52){
            impuesto = ((salario - 281.) * 20) + 60.00;
        }
        else if(salario  >= 2038.10){
            
        }
        
    }
    
    
    
}
