//
//  main.swift
//  RandomNumber
//
//  Copyright © 2019 aaa. All rights reserved.
//

import Foundation

var randomNumber = 1
var userGuess:Int? = 1
var continueGuessing = true
var keepPlaying = true
var input = ""

while (keepPlaying) {
    randomNumber = Int(arc4random_uniform(101))
    print("The random number to guess is: \(randomNumber)"  );
    while (continueGuessing) {
        print ("Pick a number between 0 and 100. ")
        input = NSString(data: NSFileHandle.fileHandleWithStandardInput().availableData, encoding:NSUTF8StringEncoding)! as String
        input = input.stringByReplacingOccurrencesOfString("\n", withString: "", options: NSStringCompareOptions.LiteralSearch, range: nil)
        userGuess = Int(input)
        if (userGuess == randomNumber) {
            continueGuessing = false
            print("Correct number!");
        }
            
        else if (userGuess > randomNumber){
           
            print("Your guess is too high");
        }
        else{
            
            print("Your guess is too low");
        }
    }
    print ("Play Again? Y or N");
    input = NSString(data: NSFileHandle.fileHandleWithStandardInput().availableData, encoding:NSUTF8StringEncoding)! as String
    input = input.stringByReplacingOccurrencesOfString("\n", withString: "", options: NSStringCompareOptions.LiteralSearch, range: nil)
    
    if (input == "N" || input == "n"){
        keepPlaying = false
    }
    continueGuessing = true
}

