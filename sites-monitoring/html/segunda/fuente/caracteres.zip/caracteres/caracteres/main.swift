//
//  main.swift
//  caracteres
//
//  Created by Alberto.
//  Copyright © 2019 Alberto. All rights reserved.
//

import Foundation


//Remover caracteresr
var input = ""
print ("Ingrese un numero")
input = NSString(data: NSFileHandle.fileHandleWithStandardInput().availableData, encoding: NSUTF8StringEncoding)! as String

input = input.stringByReplacingOccurrencesOfString("\n", withString: "", options:NSStringCompareOptions.LiteralSearch, range:nil)

print ("El numero ingresado es: \(input)")


