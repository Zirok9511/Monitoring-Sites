//
//  main.swift
//  salario
//
//  Copyright © 2019 Alberto. All rights reserved.
//

import Foundation

var salario=""
var salarioR:Double? = 0
var usvendidas=""
var usvendida:Double? = 0

var renta:Double?=0
var isss:Double?=0

var total:Double?=0
var salarioB:Double?=0
var salarioN:Double?=0

var desc1:Double?=0
var desc2:Double?=0
var totaldesc:Double?=0



print("Ingrese el salario: ")
salario = NSString(data: NSFileHandle.fileHandleWithStandardInput().availableData, encoding:NSUTF8StringEncoding)! as String

salario = salario.stringByReplacingOccurrencesOfString("\n", withString: "", options: NSStringCompareOptions.LiteralSearch, range:nil)

salarioR = Double(salario)


print("Ingrese las unidades vendidas: ")
usvendidas = NSString(data: NSFileHandle.fileHandleWithStandardInput().availableData, encoding:NSUTF8StringEncoding)! as String

usvendidas = usvendidas.stringByReplacingOccurrencesOfString("\n", withString: "", options: NSStringCompareOptions.LiteralSearch, range:nil)

usvendida = Double(usvendidas)

if (usvendida > 0 || usvendida<=100 ){
    total = usvendida! * 0.25
    salarioB! = total! + salarioR!
    
}
if (usvendida>=101 || usvendida<=200){
    total = usvendida! * 0.073
    salarioB! = total! + salarioR!
}

if (usvendida>=201 || usvendida<=500){
    total = usvendida! * 0.095
    salarioB! = total! + salarioR!
}

if (usvendida>=501)
{
    total = usvendida! * 1
    salarioB! = total! + salarioR!

}

desc1 = salarioB! * 0.10
desc1=renta

desc2 = salarioB! * 0.65
desc2=isss

totaldesc = renta! + isss!

salarioN = salarioB! - totaldesc!

print("Total devengado: \(salarioN)");



