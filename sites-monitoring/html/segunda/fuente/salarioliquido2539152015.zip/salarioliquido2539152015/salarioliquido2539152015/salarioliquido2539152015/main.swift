//
//  main.swift
//  salarioliquido2539152015
//
//  Created by Alexander on 29/11/19.
//  Copyright © 2019 Alexanderzirok. All rights reserved.
//

import Foundation
var salario="";
var conv_sal:Double? = 0;
var inputsal = "";
var salarioR:Double? = 0;
var afp:Double? = 0;
var iss:Double? = 0;
var desc:Double? = 0;
var salliquido:Double? = 0;
var KeepPlaying = true;
var input = "";
var continueGuessing = true;

while(KeepPlaying)
{
    print("Ingrese su salario");
    inputsal = NSString(data: NSFileHandle.fileHandleWithStandardInput().availableData,
        encoding: NSUTF8StringEncoding)! as String
    inputsal = inputsal.stringByReplacingOccurrencesOfString("\n", withString: "",
        options: NSStringCompareOptions.LiteralSearch,range:nil)
    
    conv_sal=Double(inputsal)
    
    
    if(conv_sal>472.01 && conv_sal<895.24)
    {
        salarioR = ((conv_sal!-472)*0.10)+17.67;
        
    }
    
    if(conv_sal>895.25 && conv_sal<2038.10 )
    {
        salarioR = ((conv_sal!-895.25)*0.20)+60.00;
    }
    
    if(conv_sal>2038.11)
    {
        salarioR = ((conv_sal!-2038.11)*0.30)+288.57
    }
    
    
    afp = conv_sal!*0.065;
    iss = conv_sal!*0.05;
    
    
    desc = salarioR!+afp!+iss!
    
    salliquido = conv_sal!-desc!;
    
    print("Salario Neto: \(conv_sal)")
    print("AFP:\(afp)")
    print("ISS:\(iss)")
    print("Renta:\(salarioR)")
    print("Total descuento:\(desc)")
    
    print("Salario liquido es de:\(salliquido)")
    
    print("Desea realizar otra operacion?: Y/N")
    
    input=NSString(data: NSFileHandle.fileHandleWithStandardInput().availableData, encoding: NSUTF8StringEncoding)! as String
    input = input.stringByReplacingOccurrencesOfString("\n", withString: "",
        options:NSStringCompareOptions.LiteralSearch,range:nil)
    
    if(input == "N" || input == "n")
    {
        KeepPlaying = false
}
}

