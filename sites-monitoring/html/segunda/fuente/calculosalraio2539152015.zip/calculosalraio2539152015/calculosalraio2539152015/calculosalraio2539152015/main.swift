//
//  main.swift
//  calculosalraio2539152015
//
//  Created by Alexander on 30/11/19.
//  Copyright © 2019 Alexanderzirok. All rights reserved.
//

import Foundation

var Unidades:Int! = 1
var Comision:Double! = 0
var Premio:Double! = 0
var keepPlaying = true
var input = ""
var Total:Double? = 0



print ("Digite las unidades vendidas")
input = NSString(data: NSFileHandle.fileHandleWithStandardInput().availableData, encoding:NSUTF8StringEncoding)! as String
input = input.stringByReplacingOccurrencesOfString("\n", withString: "", options: NSStringCompareOptions.LiteralSearch, range: nil)
Unidades = Int(input)

if(Unidades > 0 && Unidades <= 100)
{
    Total = Double(Unidades) * Double(0.5);
}
else if(Unidades <= 200)
{
    Total = Double(Unidades) * Double(0.75);
}
else if(Unidades <= 300)
{
    Total = Double(Unidades) * Double(0.95);
}
else if(Unidades <= 400)
{
    Comision = 40.00
    Total = (Double(Unidades) * 1.00) + Comision;
    
}
else{
    Comision = 40.00
    Premio = 50.00
    Total = (Double(Unidades) * 1.25) + Comision + Premio;
    
}

print("Unidades vendidas: \(Unidades)");
if(Unidades > 300){
    print("Comision calculada: \(Comision)");
    if(Unidades > 400){
        print("Su premio es: \(Premio)");
    }
}
print("Total a pagar es: \(Total)");