//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


var i=0
for i; i<10; i++
{

    print ("The index is: \(i)")
}

var index=0
for index in 1...10{
    print ("\(index) times 10 is \(index * 10)")
}
